package com.example.cars;

public enum Color {

    BLACK, RED, GREY

}
