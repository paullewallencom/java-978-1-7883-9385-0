package com.example.cars.entity;

public enum PartType {
    CHASSIS
}
