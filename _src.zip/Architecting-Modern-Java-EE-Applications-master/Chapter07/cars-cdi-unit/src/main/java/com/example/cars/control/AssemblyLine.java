package com.example.cars.control;

import com.example.cars.entity.Specification;

public class AssemblyLine {

    public void assemble(Specification specification) {
        // ...
    }

}
