package com.example.cars.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
