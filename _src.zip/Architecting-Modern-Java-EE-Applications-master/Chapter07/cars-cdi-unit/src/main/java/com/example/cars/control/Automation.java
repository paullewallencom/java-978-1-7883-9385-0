package com.example.cars.control;

public class Automation {

    public boolean isAutomated() {
        // ...
        return true;
    }

}
