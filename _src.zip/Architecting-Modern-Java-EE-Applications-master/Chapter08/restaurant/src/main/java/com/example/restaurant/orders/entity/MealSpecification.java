package com.example.restaurant.orders.entity;

public class MealSpecification {

    // ...

}
