package com.example.async.jaxrs_resource;

public class User {

    // ...

}
