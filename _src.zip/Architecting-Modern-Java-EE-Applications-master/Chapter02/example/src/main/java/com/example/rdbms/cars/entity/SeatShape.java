package com.example.rdbms.cars.entity;

public enum SeatShape {

    NORMAL, COMFORT, SPORT

}
