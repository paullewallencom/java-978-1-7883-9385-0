package com.example.factories.entity;

public class LogBook {

    // ...

}
