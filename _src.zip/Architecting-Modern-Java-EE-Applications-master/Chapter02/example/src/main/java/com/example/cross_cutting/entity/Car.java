package com.example.cross_cutting.entity;

public class Car {

    // ...

}
