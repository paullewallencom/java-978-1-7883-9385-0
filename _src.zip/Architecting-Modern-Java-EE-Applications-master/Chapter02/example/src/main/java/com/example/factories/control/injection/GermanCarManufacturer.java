package com.example.factories.control.injection;

import com.example.factories.entity.GermanCar;

public interface GermanCarManufacturer {
    GermanCar manufactureCar();
}
