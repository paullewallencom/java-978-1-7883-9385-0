package com.example.http_client.entity;

public class OrderId {

    // ...

}
