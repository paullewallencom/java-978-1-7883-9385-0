package com.example.factories.entity;

@Porsche
public class PorscheCar implements GermanCar {
}
