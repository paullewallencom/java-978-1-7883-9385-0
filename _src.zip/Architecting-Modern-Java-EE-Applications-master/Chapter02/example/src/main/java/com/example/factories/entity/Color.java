package com.example.factories.entity;

public enum Color {

    BLACK, RED, GREY

}
