package com.example.cross_cutting.entity;

public class Specification {

    // ...

}
