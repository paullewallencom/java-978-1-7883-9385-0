package com.example.configuration.entity;

public class Car {

    // ...

}
