package com.example.facades;

public interface Coffee {

    double getCaffeine();

    double getCalories();

}
