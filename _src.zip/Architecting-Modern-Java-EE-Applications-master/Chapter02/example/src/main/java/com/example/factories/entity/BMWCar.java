package com.example.factories.entity;

@BMW
public class BMWCar implements GermanCar {
}
